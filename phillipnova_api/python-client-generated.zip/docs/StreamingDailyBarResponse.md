# StreamingDailyBarResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**f** | **str** |  | [optional] 
**id** | **str** |  | [optional] 
**o** | **float** |  | [optional] 
**h** | **float** |  | [optional] 
**l** | **float** |  | [optional] 
**c** | **float** |  | [optional] 
**v** | **float** |  | [optional] 
**t** | **float** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

