# QuotesResponseV

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ask** | **float** |  | [optional] 
**bid** | **float** |  | [optional] 
**buy_pip_value** | **float** |  | [optional] 
**sell_pip_value** | **float** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

