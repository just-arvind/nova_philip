# swagger_client.AccountApi

All URIs are relative to *https://demoapi8080.phillipnova.com.sg*

Method | HTTP request | Description
------------- | ------------- | -------------
[**api_accounts_account_id_executions_get**](AccountApi.md#api_accounts_account_id_executions_get) | **GET** /api/accounts/{accountId}/executions | Get a list of executions for an account and an instrument.
[**api_accounts_account_id_instruments_get**](AccountApi.md#api_accounts_account_id_instruments_get) | **GET** /api/accounts/{accountId}/instruments | Tradeable Symbols
[**api_accounts_account_id_orders_get**](AccountApi.md#api_accounts_account_id_orders_get) | **GET** /api/accounts/{accountId}/orders | get order information
[**api_accounts_account_id_orders_history_get**](AccountApi.md#api_accounts_account_id_orders_history_get) | **GET** /api/accounts/{accountId}/ordersHistory | Get a list of history executions for an account and an instrument.
[**api_accounts_account_id_positions_get**](AccountApi.md#api_accounts_account_id_positions_get) | **GET** /api/accounts/{accountId}/positions | Get positions for an account.
[**api_accounts_account_id_state_get**](AccountApi.md#api_accounts_account_id_state_get) | **GET** /api/accounts/{accountId}/state | get account information
[**api_accounts_get**](AccountApi.md#api_accounts_get) | **GET** /api/accounts | Get a list of accounts tagged to the user.

# **api_accounts_account_id_executions_get**
> InlineResponse2009 api_accounts_account_id_executions_get(account_id, locale, instrument, max_count=max_count)

Get a list of executions for an account and an instrument.

Returns the executed fills and trades

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.AccountApi(swagger_client.ApiClient(configuration))
account_id = 'account_id_example' # str | 
locale = 'locale_example' # str | 
instrument = 'instrument_example' # str | 
max_count = 'max_count_example' # str |  (optional)

try:
    # Get a list of executions for an account and an instrument.
    api_response = api_instance.api_accounts_account_id_executions_get(account_id, locale, instrument, max_count=max_count)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AccountApi->api_accounts_account_id_executions_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **account_id** | **str**|  | 
 **locale** | **str**|  | 
 **instrument** | **str**|  | 
 **max_count** | **str**|  | [optional] 

### Return type

[**InlineResponse2009**](InlineResponse2009.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **api_accounts_account_id_instruments_get**
> InlineResponse2004 api_accounts_account_id_instruments_get(account_id, locale=locale)

Tradeable Symbols

Return the list of the instruments that are available for trading with the specified account.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.AccountApi(swagger_client.ApiClient(configuration))
account_id = 'account_id_example' # str | 
locale = 'locale_example' # str |  (optional)

try:
    # Tradeable Symbols
    api_response = api_instance.api_accounts_account_id_instruments_get(account_id, locale=locale)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AccountApi->api_accounts_account_id_instruments_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **account_id** | **str**|  | 
 **locale** | **str**|  | [optional] 

### Return type

[**InlineResponse2004**](InlineResponse2004.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **api_accounts_account_id_orders_get**
> InlineResponse2006 api_accounts_account_id_orders_get(account_id, locale)

get order information

Retrieve the order details

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.AccountApi(swagger_client.ApiClient(configuration))
account_id = 'account_id_example' # str | 
locale = 'locale_example' # str | 

try:
    # get order information
    api_response = api_instance.api_accounts_account_id_orders_get(account_id, locale)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AccountApi->api_accounts_account_id_orders_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **account_id** | **str**|  | 
 **locale** | **str**|  | 

### Return type

[**InlineResponse2006**](InlineResponse2006.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **api_accounts_account_id_orders_history_get**
> InlineResponse20010 api_accounts_account_id_orders_history_get(account_id, locale, max_count=max_count)

Get a list of history executions for an account and an instrument.

Returns the historical executed trades

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.AccountApi(swagger_client.ApiClient(configuration))
account_id = 'account_id_example' # str | 
locale = 'locale_example' # str | 
max_count = 'max_count_example' # str |  (optional)

try:
    # Get a list of history executions for an account and an instrument.
    api_response = api_instance.api_accounts_account_id_orders_history_get(account_id, locale, max_count=max_count)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AccountApi->api_accounts_account_id_orders_history_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **account_id** | **str**|  | 
 **locale** | **str**|  | 
 **max_count** | **str**|  | [optional] 

### Return type

[**InlineResponse20010**](InlineResponse20010.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **api_accounts_account_id_positions_get**
> InlineResponse2008 api_accounts_account_id_positions_get(account_id, locale)

Get positions for an account.

Retrieve the open positions of account

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.AccountApi(swagger_client.ApiClient(configuration))
account_id = 'account_id_example' # str | 
locale = 'locale_example' # str | 

try:
    # Get positions for an account.
    api_response = api_instance.api_accounts_account_id_positions_get(account_id, locale)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AccountApi->api_accounts_account_id_positions_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **account_id** | **str**|  | 
 **locale** | **str**|  | 

### Return type

[**InlineResponse2008**](InlineResponse2008.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **api_accounts_account_id_state_get**
> InlineResponse2005 api_accounts_account_id_state_get(account_id, locale)

get account information

Returns the account balance, equity and summary

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.AccountApi(swagger_client.ApiClient(configuration))
account_id = 'account_id_example' # str | 
locale = 'locale_example' # str | 

try:
    # get account information
    api_response = api_instance.api_accounts_account_id_state_get(account_id, locale)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AccountApi->api_accounts_account_id_state_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **account_id** | **str**|  | 
 **locale** | **str**|  | 

### Return type

[**InlineResponse2005**](InlineResponse2005.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **api_accounts_get**
> InlineResponse2003 api_accounts_get(locale=locale)

Get a list of accounts tagged to the user.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.AccountApi(swagger_client.ApiClient(configuration))
locale = 'locale_example' # str |  (optional)

try:
    # Get a list of accounts tagged to the user.
    api_response = api_instance.api_accounts_get(locale=locale)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AccountApi->api_accounts_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **locale** | **str**|  | [optional] 

### Return type

[**InlineResponse2003**](InlineResponse2003.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

