# HistorySuccessResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**s** | **str** |  | [optional] 
**t** | **list[float]** |  | [optional] 
**o** | **list[float]** |  | [optional] 
**h** | **list[float]** |  | [optional] 
**l** | **list[float]** |  | [optional] 
**c** | **list[float]** |  | [optional] 
**v** | **list[float]** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

