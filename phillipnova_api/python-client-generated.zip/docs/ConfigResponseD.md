# ConfigResponseD

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**account_summary_row** | [**list[ConfigResponseDAccountSummaryRow]**](ConfigResponseDAccountSummaryRow.md) |  | [optional] 
**account_manager** | [**list[ConfigResponseDAccountManager]**](ConfigResponseDAccountManager.md) |  | [optional] 
**durations** | [**list[ConfigResponseDDurations]**](ConfigResponseDDurations.md) |  | [optional] 
**order_custom_fields** | [**list[ConfigResponseDOrderCustomFields]**](ConfigResponseDOrderCustomFields.md) |  | [optional] 
**order_history_custom_fields** | [**list[ConfigResponseDOrderCustomFields]**](ConfigResponseDOrderCustomFields.md) |  | [optional] 
**position_custom_fields** | [**list[ConfigResponseDOrderCustomFields]**](ConfigResponseDOrderCustomFields.md) |  | [optional] 
**pulling_interval** | [**ConfigResponseDPullingInterval**](ConfigResponseDPullingInterval.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

