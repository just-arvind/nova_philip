# swagger_client.AuthorizationApi

All URIs are relative to *https://demoapi8080.phillipnova.com.sg*

Method | HTTP request | Description
------------- | ------------- | -------------
[**api_authorize_post**](AuthorizationApi.md#api_authorize_post) | **POST** /api/authorize | Get access token from username and password

# **api_authorize_post**
> InlineResponse200 api_authorize_post(login, password)

Get access token from username and password

Register your free Demo Username at (https://www.phillipnova.com.sg/request-a-demo-phillip-nova/)

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.AuthorizationApi(swagger_client.ApiClient(configuration))
login = 'login_example' # str | 
password = 'password_example' # str | 

try:
    # Get access token from username and password
    api_response = api_instance.api_authorize_post(login, password)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AuthorizationApi->api_authorize_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **login** | **str**|  | 
 **password** | **str**|  | 

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

