# InstrumentsResponseD

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | [optional] 
**description** | **str** |  | [optional] 
**min_qty** | **float** |  | [optional] 
**max_qty** | **float** |  | [optional] 
**qty_step** | **float** |  | [optional] 
**pip_size** | **float** |  | [optional] 
**pip_value** | **float** |  | [optional] 
**min_tick** | **float** |  | [optional] 
**lot_size** | **float** |  | [optional] 
**base_currency** | **str** |  | [optional] 
**quote_currency** | **str** |  | [optional] 
**margin_rate** | **float** |  | [optional] 
**has_quotes** | **bool** |  | [optional] 
**units** | **str** |  | [optional] 
**type** | **str** |  | [optional] 
**ui** | [**InstrumentsResponseUi**](InstrumentsResponseUi.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

