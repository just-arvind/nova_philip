# OrdersOrderIdBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**qty** | **float** |  | 
**limit_price** | **float** |  | [optional] 
**stop_price** | **float** |  | [optional] 
**duration_type** | **str** |  | [optional] 
**duration_date_time** | **float** |  | [optional] 
**stop_loss** | **float** |  | [optional] 
**trailing_stop_pips** | **float** |  | [optional] 
**take_profit** | **float** |  | [optional] 
**digital_signature** | **float** |  | [optional] 
**current_ask** | **float** |  | [optional] 
**current_bid** | **float** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

