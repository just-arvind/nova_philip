# ApiAuthorizeBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**login** | **str** | login name of user | [optional] 
**password** | **str** | password of user | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

