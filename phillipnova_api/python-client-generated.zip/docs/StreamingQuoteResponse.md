# StreamingQuoteResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**f** | **str** |  | [optional] 
**id** | **str** |  | [optional] 
**t** | **float** |  | [optional] 
**ap** | **float** |  | [optional] 
**_as** | **float** |  | [optional] 
**bp** | **float** |  | [optional] 
**bs** | **float** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

