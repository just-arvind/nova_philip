# StreamingTradeResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**f** | **str** |  | [optional] 
**id** | **str** |  | [optional] 
**p** | **float** |  | [optional] 
**s** | **float** |  | [optional] 
**t** | **float** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

