# OrdersResponseD

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**instrument** | **str** |  | [optional] 
**qty** | **float** |  | [optional] 
**side** | **str** |  | [optional] 
**type** | **str** |  | [optional] 
**avg_price** | **float** |  | [optional] 
**limit_price** | **float** |  | [optional] 
**duration** | [**OrdersResponseDuration**](OrdersResponseDuration.md) |  | [optional] 
**status** | **str** |  | [optional] 
**custom_fields** | [**list[OrdersResponseCustomFields]**](OrdersResponseCustomFields.md) |  | [optional] 
**message** | [**OrdersResponseMessage**](OrdersResponseMessage.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

