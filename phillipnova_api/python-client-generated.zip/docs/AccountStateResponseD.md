# AccountStateResponseD

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**balance** | **float** |  | [optional] 
**unrealized_pl** | **float** |  | [optional] 
**equity** | **float** |  | [optional] 
**am_data** | **list[list[list[str]]]** |  | [optional] 
**account_summary_row_data** | **list[str]** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

