# ConfigResponseDPullingInterval

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**quotes** | **float** |  | [optional] 
**orders** | **float** |  | [optional] 
**position** | **float** |  | [optional] 
**account_manager** | **float** |  | [optional] 
**balances** | **float** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

