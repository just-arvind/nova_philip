# AccountResponseUiOrderDialogCustomFieldsComboBox

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**title** | **str** |  | [optional] 
**save_to_settings** | **bool** |  | [optional] 
**mutable** | **bool** |  | [optional] 
**force_user_enter_initial_value** | **bool** |  | [optional] 
**items** | [**list[AccountResponseUiOrderDialogCustomFieldsItems]**](AccountResponseUiOrderDialogCustomFieldsItems.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

