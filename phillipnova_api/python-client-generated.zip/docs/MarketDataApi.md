# swagger_client.MarketDataApi

All URIs are relative to *https://demoapi8080.phillipnova.com.sg*

Method | HTTP request | Description
------------- | ------------- | -------------
[**api_quotes_get**](MarketDataApi.md#api_quotes_get) | **GET** /api/quotes | Get current prices of the instrument.

# **api_quotes_get**
> InlineResponse20012 api_quotes_get(account_id, locale, symbols)

Get current prices of the instrument.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.MarketDataApi(swagger_client.ApiClient(configuration))
account_id = 'account_id_example' # str | 
locale = 'locale_example' # str | 
symbols = 'symbols_example' # str | 

try:
    # Get current prices of the instrument.
    api_response = api_instance.api_quotes_get(account_id, locale, symbols)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling MarketDataApi->api_quotes_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **account_id** | **str**|  | 
 **locale** | **str**|  | 
 **symbols** | **str**|  | 

### Return type

[**InlineResponse20012**](InlineResponse20012.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

