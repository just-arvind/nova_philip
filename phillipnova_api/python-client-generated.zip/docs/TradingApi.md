# swagger_client.TradingApi

All URIs are relative to *https://demoapi8080.phillipnova.com.sg*

Method | HTTP request | Description
------------- | ------------- | -------------
[**api_accounts_account_id_orders_order_id_delete**](TradingApi.md#api_accounts_account_id_orders_order_id_delete) | **DELETE** /api/accounts/{accountId}/orders/{orderId} | Cancel an existing order.
[**api_accounts_account_id_orders_order_id_put**](TradingApi.md#api_accounts_account_id_orders_order_id_put) | **PUT** /api/accounts/{accountId}/orders/{orderId} | Modify an existing order
[**api_accounts_account_id_orders_post**](TradingApi.md#api_accounts_account_id_orders_post) | **POST** /api/accounts/{accountId}/orders | Place a new order.

# **api_accounts_account_id_orders_order_id_delete**
> InlineResponse20011 api_accounts_account_id_orders_order_id_delete(account_id, locale, order_id)

Cancel an existing order.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.TradingApi(swagger_client.ApiClient(configuration))
account_id = 'account_id_example' # str | 
locale = 'locale_example' # str | 
order_id = 'order_id_example' # str | 

try:
    # Cancel an existing order.
    api_response = api_instance.api_accounts_account_id_orders_order_id_delete(account_id, locale, order_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TradingApi->api_accounts_account_id_orders_order_id_delete: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **account_id** | **str**|  | 
 **locale** | **str**|  | 
 **order_id** | **str**|  | 

### Return type

[**InlineResponse20011**](InlineResponse20011.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **api_accounts_account_id_orders_order_id_put**
> InlineResponse20011 api_accounts_account_id_orders_order_id_put(qty, limit_price, stop_price, duration_type, duration_date_time, stop_loss, trailing_stop_pips, take_profit, digital_signature, current_ask, current_bid, locale, confirm_id, account_id, order_id)

Modify an existing order

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.TradingApi(swagger_client.ApiClient(configuration))
qty = 1.2 # float | 
limit_price = 1.2 # float | 
stop_price = 1.2 # float | 
duration_type = 'duration_type_example' # str | 
duration_date_time = 1.2 # float | 
stop_loss = 1.2 # float | 
trailing_stop_pips = 1.2 # float | 
take_profit = 1.2 # float | 
digital_signature = 1.2 # float | 
current_ask = 1.2 # float | 
current_bid = 1.2 # float | 
locale = 'locale_example' # str | 
confirm_id = 'confirm_id_example' # str | 
account_id = 'account_id_example' # str | 
order_id = 'order_id_example' # str | 

try:
    # Modify an existing order
    api_response = api_instance.api_accounts_account_id_orders_order_id_put(qty, limit_price, stop_price, duration_type, duration_date_time, stop_loss, trailing_stop_pips, take_profit, digital_signature, current_ask, current_bid, locale, confirm_id, account_id, order_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TradingApi->api_accounts_account_id_orders_order_id_put: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **qty** | **float**|  | 
 **limit_price** | **float**|  | 
 **stop_price** | **float**|  | 
 **duration_type** | **str**|  | 
 **duration_date_time** | **float**|  | 
 **stop_loss** | **float**|  | 
 **trailing_stop_pips** | **float**|  | 
 **take_profit** | **float**|  | 
 **digital_signature** | **float**|  | 
 **current_ask** | **float**|  | 
 **current_bid** | **float**|  | 
 **locale** | **str**|  | 
 **confirm_id** | **str**|  | 
 **account_id** | **str**|  | 
 **order_id** | **str**|  | 

### Return type

[**InlineResponse20011**](InlineResponse20011.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **api_accounts_account_id_orders_post**
> InlineResponse2007 api_accounts_account_id_orders_post(instrument, side, type, qty, limit_price, stop_price, duration_type, duration_date_time, stop_loss, trailing_stop_pips, take_profit, digital_signature, current_ask, current_bid, locale, request_id, confirm_id, account_id)

Place a new order.

Custom Order dialog fields defined in the accounts are sent along with the standard fields in the order object.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.TradingApi(swagger_client.ApiClient(configuration))
instrument = 'instrument_example' # str | 
side = 'side_example' # str | 
type = 'type_example' # str | 
qty = 1.2 # float | 
limit_price = 1.2 # float | 
stop_price = 1.2 # float | 
duration_type = 'duration_type_example' # str | 
duration_date_time = 1.2 # float | 
stop_loss = 1.2 # float | 
trailing_stop_pips = 1.2 # float | 
take_profit = 1.2 # float | 
digital_signature = 1.2 # float | 
current_ask = 1.2 # float | 
current_bid = 1.2 # float | 
locale = 'locale_example' # str | 
request_id = 'request_id_example' # str | 
confirm_id = 'confirm_id_example' # str | 
account_id = 'account_id_example' # str | 

try:
    # Place a new order.
    api_response = api_instance.api_accounts_account_id_orders_post(instrument, side, type, qty, limit_price, stop_price, duration_type, duration_date_time, stop_loss, trailing_stop_pips, take_profit, digital_signature, current_ask, current_bid, locale, request_id, confirm_id, account_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TradingApi->api_accounts_account_id_orders_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **instrument** | **str**|  | 
 **side** | **str**|  | 
 **type** | **str**|  | 
 **qty** | **float**|  | 
 **limit_price** | **float**|  | 
 **stop_price** | **float**|  | 
 **duration_type** | **str**|  | 
 **duration_date_time** | **float**|  | 
 **stop_loss** | **float**|  | 
 **trailing_stop_pips** | **float**|  | 
 **take_profit** | **float**|  | 
 **digital_signature** | **float**|  | 
 **current_ask** | **float**|  | 
 **current_bid** | **float**|  | 
 **locale** | **str**|  | 
 **request_id** | **str**|  | 
 **confirm_id** | **str**|  | 
 **account_id** | **str**|  | 

### Return type

[**InlineResponse2007**](InlineResponse2007.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

