# SymbolInfoResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**s** | **str** |  | [optional] 
**symbol** | **list[str]** |  | [optional] 
**description** | **list[str]** |  | [optional] 
**currency** | **list[str]** |  | [optional] 
**base_currency** | **list[str]** |  | [optional] 
**exchange_listed** | **list[str]** |  | [optional] 
**exchange_traded** | **list[str]** |  | [optional] 
**minmovement** | **list[float]** |  | [optional] 
**minmov2** | **list[float]** |  | [optional] 
**fractional** | **list[bool]** |  | [optional] 
**root** | **list[str]** |  | [optional] 
**root_description** | **list[str]** |  | [optional] 
**has_intraday** | **list[bool]** |  | [optional] 
**has_no_volume** | **list[bool]** |  | [optional] 
**type** | **list[str]** |  | [optional] 
**is_cfd** | **list[bool]** |  | [optional] 
**ticker** | **list[str]** |  | [optional] 
**timezone** | **list[str]** |  | [optional] 
**session_regular** | **list[str]** |  | [optional] 
**session_extended** | **list[str]** |  | [optional] 
**session_premarket** | **list[str]** |  | [optional] 
**session_postmarket** | **list[str]** |  | [optional] 
**supported_resolutions** | **list[list[str]]** |  | [optional] 
**has_daily** | **list[bool]** |  | [optional] 
**intraday_multipliers** | **list[list[str]]** |  | [optional] 
**has_weekly_and_monthly** | **list[bool]** |  | [optional] 
**pointvalue** | **list[float]** |  | [optional] 
**expiration** | **list[float]** |  | [optional] 
**bar_source** | **list[str]** |  | [optional] 
**bar_transform** | **list[str]** |  | [optional] 
**bar_fillgaps** | **list[bool]** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

