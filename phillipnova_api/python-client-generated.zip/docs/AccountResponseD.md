# AccountResponseD

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**type** | **str** |  | [optional] 
**currency** | **str** |  | [optional] 
**currency_sign** | **str** |  | [optional] 
**config** | [**AccountResponseConfig**](AccountResponseConfig.md) |  | [optional] 
**ui** | [**AccountResponseUi**](AccountResponseUi.md) |  | [optional] 
**durations** | [**list[ConfigResponseDDurations]**](ConfigResponseDDurations.md) |  | [optional] 
**prefix** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

