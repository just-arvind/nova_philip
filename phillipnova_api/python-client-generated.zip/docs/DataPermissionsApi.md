# swagger_client.DataPermissionsApi

All URIs are relative to *https://demoapi8080.phillipnova.com.sg*

Method | HTTP request | Description
------------- | ------------- | -------------
[**api_groups_get**](DataPermissionsApi.md#api_groups_get) | **GET** /api/groups | Get current prices of the instrument.
[**api_permissions_get**](DataPermissionsApi.md#api_permissions_get) | **GET** /api/permissions | Get a list of symbol groups allowed for the user. It is only required if you use groups of symbols to restrict access to instrument&#x27;s data.

# **api_groups_get**
> InlineResponse20013 api_groups_get()

Get current prices of the instrument.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.DataPermissionsApi(swagger_client.ApiClient(configuration))

try:
    # Get current prices of the instrument.
    api_response = api_instance.api_groups_get()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DataPermissionsApi->api_groups_get: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse20013**](InlineResponse20013.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **api_permissions_get**
> InlineResponse20014 api_permissions_get()

Get a list of symbol groups allowed for the user. It is only required if you use groups of symbols to restrict access to instrument's data.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.DataPermissionsApi(swagger_client.ApiClient(configuration))

try:
    # Get a list of symbol groups allowed for the user. It is only required if you use groups of symbols to restrict access to instrument's data.
    api_response = api_instance.api_permissions_get()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DataPermissionsApi->api_permissions_get: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse20014**](InlineResponse20014.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

