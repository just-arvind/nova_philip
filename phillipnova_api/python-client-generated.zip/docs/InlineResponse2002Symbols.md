# InlineResponse2002Symbols

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**f** | **list[str]** |  | [optional] 
**s** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

