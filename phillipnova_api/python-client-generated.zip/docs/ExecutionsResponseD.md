# ExecutionsResponseD

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**instrument** | **str** |  | [optional] 
**price** | **float** |  | [optional] 
**time** | **float** |  | [optional] 
**qty** | **float** |  | [optional] 
**side** | **str** |  | [optional] 
**order_id** | **str** |  | [optional] 
**is_close** | **bool** |  | [optional] 
**position_id** | **str** |  | [optional] 
**commission** | **float** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

