# ConfigResponseDDurations

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**title** | **str** |  | [optional] 
**has_date_picker** | **bool** |  | [optional] 
**has_time_picker** | **bool** |  | [optional] 
**default** | **bool** |  | [optional] 
**supported_order_types** | **list[str]** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

