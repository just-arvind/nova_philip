# swagger_client.BrokerConfigurationApi

All URIs are relative to *https://demoapi8080.phillipnova.com.sg*

Method | HTTP request | Description
------------- | ------------- | -------------
[**api_config_get**](BrokerConfigurationApi.md#api_config_get) | **GET** /api/config | Get localized configuration.
[**api_mapping_get**](BrokerConfigurationApi.md#api_mapping_get) | **GET** /api/mapping | Return all broker instrument symbol from user entitlement

# **api_config_get**
> InlineResponse2001 api_config_get(locale=locale)

Get localized configuration.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.BrokerConfigurationApi()
locale = 'locale_example' # str |  (optional)

try:
    # Get localized configuration.
    api_response = api_instance.api_config_get(locale=locale)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling BrokerConfigurationApi->api_config_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **locale** | **str**|  | [optional] 

### Return type

[**InlineResponse2001**](InlineResponse2001.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **api_mapping_get**
> InlineResponse2002 api_mapping_get()

Return all broker instrument symbol from user entitlement

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.BrokerConfigurationApi()

try:
    # Return all broker instrument symbol from user entitlement
    api_response = api_instance.api_mapping_get()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling BrokerConfigurationApi->api_mapping_get: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse2002**](InlineResponse2002.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

