# swagger_client.DataIntegrationApi

All URIs are relative to *https://demoapi8080.phillipnova.com.sg*

Method | HTTP request | Description
------------- | ------------- | -------------
[**api_history_get**](DataIntegrationApi.md#api_history_get) | **GET** /api/history | Request for history bars
[**api_symbol_info_get**](DataIntegrationApi.md#api_symbol_info_get) | **GET** /api/symbol_info | Get a list of all instruments.
[**streaming_get**](DataIntegrationApi.md#streaming_get) | **GET** /streaming | Price server endpoint (https://demoapi8081.phillipnova.com.sg/streaming)

# **api_history_get**
> InlineResponse20016 api_history_get(symbol, resolution, _from, to, countback=countback)

Request for history bars

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.DataIntegrationApi(swagger_client.ApiClient(configuration))
symbol = 'symbol_example' # str | 
resolution = 'resolution_example' # str | 
_from = '_from_example' # str | 
to = 'to_example' # str | 
countback = 'countback_example' # str |  (optional)

try:
    # Request for history bars
    api_response = api_instance.api_history_get(symbol, resolution, _from, to, countback=countback)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DataIntegrationApi->api_history_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **symbol** | **str**|  | 
 **resolution** | **str**|  | 
 **_from** | **str**|  | 
 **to** | **str**|  | 
 **countback** | **str**|  | [optional] 

### Return type

[**InlineResponse20016**](InlineResponse20016.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **api_symbol_info_get**
> InlineResponse20015 api_symbol_info_get(group)

Get a list of all instruments.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.DataIntegrationApi(swagger_client.ApiClient(configuration))
group = 'group_example' # str | 

try:
    # Get a list of all instruments.
    api_response = api_instance.api_symbol_info_get(group)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DataIntegrationApi->api_symbol_info_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **group** | **str**|  | 

### Return type

[**InlineResponse20015**](InlineResponse20015.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **streaming_get**
> InlineResponse20017 streaming_get()

Price server endpoint (https://demoapi8081.phillipnova.com.sg/streaming)

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.DataIntegrationApi(swagger_client.ApiClient(configuration))

try:
    # Price server endpoint (https://demoapi8081.phillipnova.com.sg/streaming)
    api_response = api_instance.streaming_get()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DataIntegrationApi->streaming_get: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse20017**](InlineResponse20017.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

